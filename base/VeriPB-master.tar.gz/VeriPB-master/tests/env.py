from os import sys, path

sys.path.insert(0,path.abspath(path.join(path.dirname(__file__), "..")))

import veripb